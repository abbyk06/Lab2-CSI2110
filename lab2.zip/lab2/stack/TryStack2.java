public class TryStack2 {

    // Change this file as much or as little as you need to.

    /**
     * Main driver method that will reverse an array.
     *
     * @param args
     */
    public static void main(String[] args) {

    }
}
